package com.bank.dao;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Dao_Test {
	BankDAO bd = new BankDAO();
	
	@Test
	public void Search()
	{
		assertTrue("This succeeds.", true);
		//assertTrue("This will fail!", false);
	}

}
