package com.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UtilJava {

	private static EntityManagerFactory factory;

	private static EntityManager entityManager;

	public static EntityManager getEntityManager() {
		factory = Persistence.createEntityManagerFactory("Parallel");

		entityManager = factory.createEntityManager();

		return entityManager;
	}

}
