package com.capg.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.entity.bankEntity;
import com.capg.entity.transactionEntity;
import com.capg.service.bankService;
public class Client {
	
	 
		public static void main(String[] args) {
			
		Scanner scanner  = new Scanner(System.in);      
           ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
   		bankService bankService =  context.getBean("bankService",bankService.class);
	   String str;
			int c,balance;
			String choice,name,password,phoneNo;
			
			while(true)
			{
				System.out.println("***********************************");

				System.out.println("Press 1 to create the account");
				System.out.println("Press 2 to show the balance");
				System.out.println("Press 3 to deposit the balance");
				System.out.println("Press 4 to withdraw money");
				System.out.println("Press 5 for the fund transfer");
				System.out.println("Press 6 to print transaction");
				System.out.println("Press 7 for exit");
				
	          	
					System.out.println("Enter the choice : ");
				 str = scanner.next();
				
				
				if(str.matches("[a-z]*")||str.matches("[A-Z]*"))
				{	     
					System.out.println("You have enterted Invalid Choice!!!");
					main(null);
	            }
				
				
				switch (str) {
				case "1":


					System.out.println("Welcome to Capgemini Bank");


					do
					{
						System.out.println("Enter your name");
						name = scanner.next();
						c =bankService.nameValidate(name);
					}
					while(c!=1);
					
					
					do
					{
						System.out.println("enter phone number");
						phoneNo = scanner.next();
						c = bankService.mobNoValidate(phoneNo);
					}
					while(c!=1);
	                 
					long phone1 = Long.parseLong(phoneNo);
					long accountNo = phone1 + 1;

					do
					{
						System.out.println("create your password");
						password = scanner.next();
						c = bankService.passwordValidate(password);
					}
					while(c!=1);

					do
					{
						System.out.println("enter the balance");
						balance = scanner.nextInt();
						c = bankService.checkBalance(balance);
					}
					while(c!=1);
					
					boolean result =  bankService.createAccount(name,phoneNo,password,accountNo,balance);
					if(result)
					{
						System.out.println("Account created successful: "+accountNo);
					}
					break;

				case "2":

					System.out.println("Enter your account number");
					accountNo = scanner.nextLong();
					System.out.println("Enter your password");
					password = scanner.next();
					boolean b1= bankService.validateAccount(accountNo,password);
					if(b1)
					{
							balance = bankService.showBalance(accountNo);
							if(balance!=0)
							{
								System.out.println("Your account balance is "+balance);
							}
							else
							{
								System.out.println("Problem ");
							}
					}
					else
					{
						System.out.println("you have entered wrong credentials");
					}

					break;
				case "3":
					System.out.println("Enter the account number");
					accountNo = scanner.nextLong();
					System.out.println("Enter your password");
					password = scanner.next();
					boolean b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						System.out.println("Enter amount to be deposited");
						int deposit = scanner.nextInt();
						balance = bankService.depositAmount(accountNo,deposit);
						System.out.println("Amount deposited");
						System.out.println("your updated balance is "+balance);
					}
					else
					{
						System.out.println("wrong credentials");
					}
					break;
				case "4":

					System.out.println("Enter your account number");
					accountNo = scanner.nextLong();
					System.out.println("Enter your password");
					password = scanner.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						balance = bankService.showBalance(accountNo);
						System.out.println("Your current balance is "+balance);
						System.out.println("Enter the amount for withdrawal");
						int withdraw = scanner.nextInt();
							balance = bankService.withdrawAmount(accountNo,withdraw);
							if(balance>=0)
							{
								System.out.println("Amount withdrawal");
								System.out.println("You debited "+withdraw);
								System.out.println("your updated balance is "+balance+"\n");
							}
							else
							{
                                 System.out.println("Insufficient funds");
							}
						}
						
					
					else
					{
				               System.out.println("wrong credential");
					}
					break;
					
				case "5":

					System.out.println("Enter your account number");
					accountNo = scanner.nextLong();
					System.out.println("Enter your password");
					password = scanner.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						System.out.println("\n Enter account number to transfer");
						long  accno = scanner.nextLong();
						System.out.println("Enter the amount to transfer");
						int amount = scanner.nextInt();
						boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
						if(transfer)
						{
							System.out.println(amount+ " is transferred successfully!! \n");
						}
						else
						{
						  System.out.println("Problem is in transfer");
						}
					}
					else
					{
						System.out.println("Invalid account");
					}

					break;
				case "6":
					System.out.println("Enter your account number");
					accountNo = scanner.nextLong();
					System.out.println("Enter your password");
					password = scanner.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
	                    List<transactionEntity> trans=bankService.getTransaction(accountNo);

						System.out.println("*******Account Statement***********\n");

						for(transactionEntity tran:trans)
						{
							System.out.println(tran);
						}

					}
					else 
					{
						System.out.println("Account does not exist!");
					}
					break;
					
				case "7": 
					System.out.println("Thanks for visiting");
					System.exit(0);
				}

			}
	
	}

}
