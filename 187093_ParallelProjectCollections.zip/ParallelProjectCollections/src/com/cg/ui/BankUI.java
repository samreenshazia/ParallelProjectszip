package com.cg.ui;

import java.util.Scanner;

import com.cg.exceptions.*;
import com.cg.service.BankService;
import com.cg.service.BankServiceI;

public class BankUI {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException {

		// variables

		long accNo, accNo1;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean res = false;
		String cont = "yes";

		BankServiceI service = new BankService();

		// To ask choice from users and perform operations
		while (cont.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// to create account

			case 1:

				System.out.println("Enter the name");
				String name = scanner.nextLine();
				name += scanner.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format");
					System.out.println("Enter the name");
					name = scanner.next();
				}

				System.out.println("Enter the address ");
				String add = scanner.next();
				add += scanner.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter the address ");
					add = scanner.nextLine();

				}

				System.out.println("Enter the phone number");
				String phone = scanner.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be 10 digits");
						System.out.println("Enter the phone number");
						phone = scanner.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.println("Enter the phone number");
					phone = scanner.next();
				}

				accNo = Long.parseLong(phone) - 10000;

				System.out.println("Enter the Pin");
				pin = scanner.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be 4 digits");
					System.out.println("Enter the Pin");
					pin = scanner.nextInt();
				}

				System.out.println("Enter the Balance");
				int bal = scanner.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter the Balance");
					bal = scanner.nextInt();

				}
				try {
					res = service.createAccount(name, add, accNo, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (res == true) {
					System.out.println("Account Created Successfully");
					System.out.println("Account Number : " + accNo);

				} else {

					System.out.println("Cannot Create the Account");
				}

				break;

			// to show balance
			case 2:

				System.out.println("Enter the account number");
				accNo = scanner.nextLong();

				try {
					balance = service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit

			case 3:

				System.out.println("Enter the account no");
				accNo = scanner.nextLong();

				System.out.println("Enter the amount to be deposited");
				deposit_amount = scanner.nextInt();

				try {
					amount = service.deposit(accNo, deposit_amount);

					balance = service.showBalance(accNo);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + deposit_amount);
				System.out.println("Updated Balance : " + balance);

				break;

			// to withdraw

			case 4:

				System.out.println("Enter the account no");
				accNo = scanner.nextLong();

				System.out.println("Enter the amount to withdraw");
				withdraw_amount = scanner.nextInt();

				try {
					amount = service.withdraw(accNo, withdraw_amount);
					res = service.validateBalance(accNo, withdraw_amount);
					balance = service.showBalance(accNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdraw_amount);
				System.out.println("Updated Balance : " + balance);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter the account no");
				accNo = scanner.nextLong();

				System.out.println("Enter the account to which you want to transfer fund");
				accNo1 = scanner.nextLong();

				System.out.println("Enter the amount to transfer");
				transfer_amount = scanner.nextInt();

				try {
					res = service.validateBalance(accNo, transfer_amount);
					res = service.transferfund(accNo, accNo1, transfer_amount);

					senders_balance = service.showBalance(accNo);
					recievers_balance = service.showBalance(accNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully!!!");
				System.out.println("Updated balance for Account " + accNo + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accNo1 + " : " + recievers_balance);

				break;

			// to show transactions
			case 6:

				String s = null;
				System.out.println("Enter the account number");
				accNo = scanner.nextLong();
				System.out.println("Enter the pin");
				pin = scanner.nextInt();
				try {
					s = service.setTrans(accNo);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}
				break;
				// to exit
			case 7:
				
				System.out.println("Exit");
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter the choice between 1 - 7 ");
				menu();

			}
		}

	}

	// to display menu
	public static int menu() {

		System.out.println("*************Welcome to Capgemini Bank**************");
		System.out.println("Press 1 to Create a Account");
		System.out.println("Press 2 to Show the Balance");
		System.out.println("Press 3 to Deposit money");
		System.out.println("Press 4 to Withdraw money");
		System.out.println("Press 5 to Transer the Fund");
		System.out.println("Press 6 to Print the Transcations");
		System.out.println("Press 7 to Exit");

		System.out.println("Enter the Choice");
		int choice =scanner.nextInt();

		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Chice");
			System.out.println("Enter Choice");
			choice = scanner.nextInt();
		}
		return choice;
	}

}
