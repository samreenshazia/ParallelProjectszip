package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.BankBean;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.LowBalanceException;

public class BankDao implements BankDaoI {

	HashMap hashMap;

	public BankDao() {

		hashMap = new HashMap();
	}

	// bean class object

	BankBean bean = new BankBean();

	// to check account already exists or not

	public BankBean checkAccount(long accNo) {

		if (hashMap.containsKey(accNo)) {

			bean = (BankBean) hashMap.get(accNo);
			return bean;

		} else

			return null;
	}

	// to put the data into the map

	public void setData(long accNo, BankBean bean) {

		hashMap.put(accNo, bean);
	}

}
