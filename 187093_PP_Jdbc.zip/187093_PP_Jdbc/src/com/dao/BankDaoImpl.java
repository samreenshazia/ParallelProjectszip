package com.dao;

import java.sql.SQLException;

import com.bean.BankBean;
import com.bean.Transactions;

public interface BankDaoImpl {

	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException;

	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException;

	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException;

	public void setTransactions(Transactions transaction) throws ClassNotFoundException, SQLException;

	public Transactions getTransactions(long accNo) throws ClassNotFoundException, SQLException;

}
