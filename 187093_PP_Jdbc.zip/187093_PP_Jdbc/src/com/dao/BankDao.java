package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.BankBean;
import com.bean.Transactions;

public class BankDao implements BankDaoImpl {

	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	BankBean bank = new BankBean();

	@Override
	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;
		String query = "SELECT * FROM BankBean WHERE accNo = ?";
		connection = BankDatabase.getConnection();
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setLong(1, accNo);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			res = false;
		} else {
			res = true;
		}
		return res;
	}

	@Override
	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException {
		connection = BankDatabase.getConnection();
		preparedStatement = connection.prepareStatement("INSERT INTO BankBean VALUES(?,?,?,?,?,?)");
		preparedStatement.setString(1, bean.getName());
		preparedStatement.setLong(2, bean.getAccno());
		preparedStatement.setLong(3, bean.getPin());
		preparedStatement.setString(4, bean.getAddress());
		preparedStatement.setString(5, bean.getPhone());
		preparedStatement.setInt(6, bean.getBalance());
		int r = preparedStatement.executeUpdate();
		if (r == 0) {
			System.out.println("row Not inserted");
		} else {
			System.out.println("Value inserted succesfully");
		}
	}

	@Override
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException {
		connection = BankDatabase.getConnection();
		preparedStatement = connection.prepareStatement("UPDATE BankBean SET BALANCE = ? WHERE accNo = ?");
		preparedStatement.setInt(1, bean.getBalance());
		preparedStatement.setLong(2, bean.getAccno());
		int r = preparedStatement.executeUpdate();
		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;
		String query = "SELECT * FROM BankBean WHERE accNo = ?";
		connection = BankDatabase.getConnection();
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setLong(1, accNo);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			bank.setName(resultSet.getString(1));
			bank.setAccNo(resultSet.getLong(2));
			bank.setPin(resultSet.getInt(3));
			bank.setAddress(resultSet.getString(4));
			bank.setPhone(resultSet.getString(5));
			bank.setBalance(resultSet.getInt(6));
		} else {
			bank = null;
		}
		return bank;
	}

	@Override
	public void setTransactions(Transactions trans) throws ClassNotFoundException, SQLException {
		String query = "INSERT INTO Transactions VALUES(?,?,?,?)";
		connection = BankDatabase.getConnection();
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setString(1, trans.getType());
		preparedStatement.setLong(2, trans.getAccNo());
		preparedStatement.setInt(3, trans.getAmount());
		preparedStatement.setInt(4, trans.getTransactionId());
		int res = preparedStatement.executeUpdate();
		if (res == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}
	}

	@Override
	public Transactions getTransactions(long accNo) throws ClassNotFoundException, SQLException {
		Transactions trans = new Transactions();
		String query = "SELECT * FROM Transactions WHERE accNo = ?";
		connection = BankDatabase.getConnection();
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setLong(1, accNo);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			trans.setType(resultSet.getString(1));
			trans.setAccNo(resultSet.getLong(2));
			trans.setAmount(resultSet.getInt(3));
			trans.setTransactionId(resultSet.getInt(4));
		}
		return trans;
	}
}